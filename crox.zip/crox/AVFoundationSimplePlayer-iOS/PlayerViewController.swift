/*
 Copyright (C) 2017 G.O. Eden Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller containing a player view and basic playback controls.
 */

import Foundation
import AVFoundation
import UIKit
import AudioToolbox
import Firebase
import FirebaseStorage

/*
 KVO context used to differentiate KVO callbacks for this class versus other
 classes in its class hierarchy.
 */
private var playerViewControllerKVOContext = 0

class PlayerViewController: UIViewController, AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    
    @IBOutlet weak var timeSlider: UISlider!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var getButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var helpButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var getHelp: UIView!
    @IBOutlet weak var playHelp: UIView!
    @IBOutlet weak var playerView: PlayerView!
    
    // MARK: Properties
    var recorder : AVAudioRecorder?
    var testPlayer: AVPlayer!
    var propanePlayer: AVPlayer!
    
    var currentTime: Double {
        get {
            return CMTimeGetSeconds(player.currentTime())
        }
        set {
            let newTime = CMTimeMakeWithSeconds(newValue, 2000)
            player.seek(to: newTime, toleranceBefore: kCMTimeZero, toleranceAfter: kCMTimeZero)
        }
    }
    
    // Attempt load and test these asset keys before playing.
    static let assetKeysRequiredToPlay = [
        "playable",
        "hasProtectedContent"
    ]
    
    let player = AVPlayer()
    
    var timeBeforeStamp: Double {
        get {
            return CMTimeGetSeconds(player.currentTime())
        }
        set {
            let newTime = CMTimeMakeWithSeconds(newValue, 1)
            player.seek(to: newTime, toleranceBefore: kCMTimeZero, toleranceAfter: kCMTimeZero)
        }
    }
    
    var duration: Double {
        guard let currentItem = player.currentItem else { return 0.0 }
        
        return CMTimeGetSeconds(currentItem.duration)
    }
    
    var rate: Float {
        get {
            return player.rate
        }
        
        set {
            player.rate = newValue
        }
    }
    
    var asset: AVURLAsset? {
        didSet {
            guard let newAsset = asset else { return }
            
            asynchronouslyLoadURLAsset(newAsset)
        }
    }
    
    private var playerLayer: AVPlayerLayer? {
        return playerView.playerLayer
    }
    
    /*
     A formatter for individual date components used to provide an appropriate
     value for the `startTimeLabel` and `durationLabel`.
     */
    let timeRemainingFormatter: DateComponentsFormatter = {
        let formatter = DateComponentsFormatter()
        formatter.zeroFormattingBehavior = .pad
        formatter.allowedUnits = [.minute, .second]
        
        return formatter
    }()
    
    /*
     A token obtained from calling `player`'s `addPeriodicTimeObserverForInterval(_:queue:usingBlock:)`
     method.
     */
    private var timeObserverToken: Any?
    
    private var playerItem: AVPlayerItem? = nil {
        didSet {
            /*
             If needed, configure player item here before associating it with a player. (example: adding outputs, setting text style rules, selecting media options)
             */
            player.replaceCurrentItem(with: self.playerItem)
        }
    }
    
    // MARK: - View Controller
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        playerView.isHidden = true
        timeSlider.isHidden = true
        startTimeLabel.isHidden = true
        durationLabel.isHidden = true
        getHelp.isHidden = false
        playHelp.isHidden = true
        
//        playerView.isHidden = false
//        timeSlider.isHidden = false
//        startTimeLabel.isHidden = false
//        durationLabel.isHidden = false
        
        /*
         Update the UI when these player properties change.
         
         Use the context parameter to distinguish KVO for our particular observers
         and not those destined for a subclass that also happens to be observing
         these properties.
         */
        addObserver(self, forKeyPath: #keyPath(PlayerViewController.player.currentItem.duration), options: [.new, .initial], context: &playerViewControllerKVOContext)
        addObserver(self, forKeyPath: #keyPath(PlayerViewController.player.rate), options: [.new, .initial], context: &playerViewControllerKVOContext)
        addObserver(self, forKeyPath: #keyPath(PlayerViewController.player.currentItem.status), options: [.new, .initial], context: &playerViewControllerKVOContext)
        
        playerView.playerLayer.player = player
        
        FIRStorage.storage().reference().child("tennesseeWhiskey.m4a").downloadURL { (url, error) in
            if let error = error {
                print(error.localizedDescription)
            } else {
                self.asset = AVURLAsset(url: url!, options: nil)
                let localUrl = self.documentUrl(for: "tennesseeWhiskey.m4a")
                self.download(url: url!, to: localUrl) {
                if let file = self.openAudioFile(url: localUrl),
                let buffer = self.readIntoFloatBuffer(file: file) {
                self.writeFloatBuffer(buffer, intoFile: "tennesseeWhiskey.txt")
                }
            }
        }
        }
        // Make sure we don't have a strong reference cycle by only capturing self as weak.
        
        let interval = CMTimeMake(1, 1)
        timeObserverToken = player.addPeriodicTimeObserver(forInterval: interval, queue: DispatchQueue.main) { [unowned self] time in
            let timeElapsed = Float(CMTimeGetSeconds(time))
            
            self.timeSlider.value = Float(timeElapsed)
            self.startTimeLabel.text = self.createTimeString(time: timeElapsed)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupAudioSession()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        if let timeObserverToken = timeObserverToken {
            player.removeTimeObserver(timeObserverToken)
            self.timeObserverToken = nil
        }
        
        player.pause()
        
        removeObserver(self, forKeyPath: #keyPath(PlayerViewController.player.currentItem.duration), context: &playerViewControllerKVOContext)
        removeObserver(self, forKeyPath: #keyPath(PlayerViewController.player.rate), context: &playerViewControllerKVOContext)
        removeObserver(self, forKeyPath: #keyPath(PlayerViewController.player.currentItem.status), context: &playerViewControllerKVOContext)
    }
    
    //set audio session for recording and get recorder ready
    
    func setupAudioSession() {
        let fileMgr = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let recordUrl = fileMgr[0].appendingPathComponent("recording.m4a")
        
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord)
        session.requestRecordPermission { (bool) in}
        try! session.setActive(true)
        
        let recordSettings: [String : AnyObject] =
            [AVSampleRateKey : NSNumber(value: Float(11025.0)),
             AVFormatIDKey : NSNumber(value: Int32(kAudioFormatMPEG4AAC)),
             AVNumberOfChannelsKey : NSNumber(value: Int32(1)),
             AVEncoderAudioQualityKey : NSNumber(value: Int32(AVAudioQuality.medium.rawValue))]
        do {
            recorder = try AVAudioRecorder(url: recordUrl, settings: recordSettings)
        } catch {
            print(error.localizedDescription)
        }
        recorder?.delegate = self
        recorder?.prepareToRecord()
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
                if flag {
                    
                playHelp.isHidden = false
                    
                let localUrl = self.documentUrl(for: "tennesseeWhiskey.m4a")
                if let filmSourceAudio = self.openAudioFile(url: localUrl),
                let sourceBuffer = self.readIntoFloatBuffer(file: filmSourceAudio) {
                if let recording = openAudioFile(url: recorder.url),
                let recordingBuffer = readIntoFloatBuffer(file: recording) {
                
                var movie = sourceBuffer // 12934151
                    
                var movieTrim = movie[0...12921299]
                    
                var movieFiltered : [Float] = []
                var frequency = 0
                var begin = 0
                var end = 19999
                while ( frequency < movieTrim.count / 44100 ) {
                var twentyThousand = movieTrim[begin...end]
                var zeroes = Array(repeating: Float(0), count: 24100)
                twentyThousand += zeroes
                movieFiltered += twentyThousand
                frequency += 1
                begin += 44100
                end += 44100
                }
                    
                var movieDownsampled : [Float] = []  // count = 3230325
                var sample = 0
                var start = 0
                var finish = 3
                let fourSamples = 4
                while ( sample < movieFiltered.count / fourSamples ) {
                let groupOfFour = movieFiltered[start...finish]
                let sum = groupOfFour.reduce(0, +)
                let average = sum / 4
                movieDownsampled += [average]
                sample += 1
                start += 4
                finish += 4
                }
                    
                var realNotesFirst : [Float] = []
                var note = 0
                var first = 0
                var last = 1023
                while ( note < movieDownsampled.count / 1024 ) {
                var notes = movieDownsampled[first...last]
                var realNotes = notes.enumerated().flatMap { index, element in index % 2 == 1 ? nil : element }
                var unrealNotes = Array(repeating: Float(0), count: 512)
                realNotes += unrealNotes
                realNotesFirst += realNotes
                note += 1
                first += 1024
                last += 1024
                }
                    
                var rangeOne : [Float] = []
                var spaceOne = 0
                var rangeOneFrom = 0
                var rangeOneTo = 9
                while ( spaceOne < realNotesFirst.count / 1024 ) {
                var rangeOneSpaces = realNotesFirst[rangeOneFrom...rangeOneTo]
                rangeOne += rangeOneSpaces
                spaceOne += 1
                rangeOneFrom += 1024
                rangeOneTo += 1024
                }
                    
                var rangeTwo : [Float] = []
                var spaceTwo = 0
                var rangeTwoFrom = 10
                var rangeTwoTo = 20
                while ( spaceTwo < realNotesFirst.count / 1024 ) {
                var rangeTwoSpaces = realNotesFirst[rangeTwoFrom...rangeTwoTo]
                rangeTwo += rangeTwoSpaces
                spaceTwo += 1
                rangeTwoFrom += 1024
                rangeTwoTo += 1024
                }
                    
                var rangeThree : [Float] = []
                var spaceThree = 0
                var rangeThreeFrom = 21
                var rangeThreeTo = 40
                while ( spaceThree < realNotesFirst.count / 1024 ) {
                var rangeThreeSpaces = realNotesFirst[rangeThreeFrom...rangeThreeTo]
                rangeThree += rangeThreeSpaces
                spaceThree += 1
                rangeThreeFrom += 1024
                rangeThreeTo += 1024
                }
                    
                var rangeFour : [Float] = []
                var spaceFour = 0
                var rangeFourFrom = 41
                var rangeFourTo = 80
                while ( spaceFour < realNotesFirst.count / 1024 ) {
                var rangeFourSpaces = realNotesFirst[rangeFourFrom...rangeFourTo]
                rangeFour += rangeFourSpaces
                spaceFour += 1
                rangeFourFrom += 1024
                rangeFourTo += 1024
                }
                    
                var rangeFive : [Float] = []
                var spaceFive = 0
                var rangeFiveFrom = 81
                var rangeFiveTo = 160
                while ( spaceFive < realNotesFirst.count / 1024 ) {
                var rangeFiveSpaces = realNotesFirst[rangeFiveFrom...rangeFiveTo]
                rangeFive += rangeFiveSpaces
                spaceFive += 1
                rangeFiveFrom += 1024
                rangeFiveTo += 1024
                }
                    
                var rangeSix : [Float] = []
                var spaceSix = 0
                var rangeSixFrom = 161
                var rangeSixTo = 511
                while ( spaceSix < realNotesFirst.count / 1024 ) {
                var rangeSixSpaces = realNotesFirst[rangeSixFrom...rangeSixTo]
                rangeSix += rangeSixSpaces
                spaceSix += 1
                rangeSixFrom += 1024
                rangeSixTo += 1024
                }

                var rangeOneMaxes : [Float] = []
                var portionOne = 0
                var rangeOneMaxesInitial = 0
                var rangeOneMaxesFinal = 9
                while ( portionOne < rangeOne.count / 10 ) {
                var rangeOneMaxesPortion = rangeOne[rangeOneMaxesInitial...rangeOneMaxesFinal]
                var maxOne = rangeOneMaxesPortion.max()
                rangeOneMaxes += [maxOne!]
                portionOne += 1
                rangeOneMaxesInitial += 10
                rangeOneMaxesFinal += 10
                }
        
                var rangeTwoMaxes : [Float] = []
                var portionTwo = 0
                var rangeTwoMaxesInitial = 0
                var rangeTwoMaxesFinal = 9
                while ( portionTwo < rangeTwo.count / 10 ) {
                var rangeTwoMaxesPortion = rangeTwo[rangeTwoMaxesInitial...rangeTwoMaxesFinal]
                var maxTwo = rangeTwoMaxesPortion.max()
                rangeTwoMaxes += [maxTwo!]
                portionTwo += 1
                rangeTwoMaxesInitial += 10
                rangeTwoMaxesFinal += 10
                }
                    
                var rangeThreeMaxes : [Float] = []
                var portionThree = 0
                var rangeThreeMaxesInitial = 0
                var rangeThreeMaxesFinal = 9
                while ( portionThree < rangeThree.count / 10 ) {
                var rangeThreeMaxesPortion = rangeThree[rangeThreeMaxesInitial...rangeThreeMaxesFinal]
                var maxThree = rangeThreeMaxesPortion.max()
                rangeThreeMaxes += [maxThree!]
                portionThree += 1
                rangeThreeMaxesInitial += 10
                rangeThreeMaxesFinal += 10
                }
                    
                var rangeFourMaxes : [Float] = []
                var portionFour = 0
                var rangeFourMaxesInitial = 0
                var rangeFourMaxesFinal = 9
                while ( portionFour < rangeFour.count / 10 ) {
                var rangeFourMaxesPortion = rangeFour[rangeFourMaxesInitial...rangeFourMaxesFinal]
                var maxFour = rangeFourMaxesPortion.max()
                rangeFourMaxes += [maxFour!]
                portionFour += 1
                rangeFourMaxesInitial += 10
                rangeFourMaxesFinal += 10
                }
                    
                var rangeFiveMaxes : [Float] = []
                var portionFive = 0
                var rangeFiveMaxesInitial = 0
                var rangeFiveMaxesFinal = 9
                while ( portionFive < rangeFive.count / 10 ) {
                var rangeFiveMaxesPortion = rangeFive[rangeFiveMaxesInitial...rangeFiveMaxesFinal]
                var maxFive = rangeFiveMaxesPortion.max()
                rangeFiveMaxes += [maxFive!]
                portionFive += 1
                rangeFiveMaxesInitial += 10
                rangeFiveMaxesFinal += 10
                }
                    
                var rangeSixMaxes : [Float] = []
                var portionSix = 0
                var rangeSixMaxesInitial = 0
                var rangeSixMaxesFinal = 9
                while ( portionSix < rangeSix.count / 10 ) {
                var rangeSixMaxesPortion = rangeSix[rangeSixMaxesInitial...rangeSixMaxesFinal]
                var maxSix = rangeSixMaxesPortion.max()
                rangeSixMaxes += [maxSix!]
                portionSix += 1
                rangeSixMaxesInitial += 10
                rangeSixMaxesFinal += 10
                }
                    
                var maxes = rangeOneMaxes + rangeTwoMaxes + rangeThreeMaxes + rangeFourMaxes + rangeFiveMaxes + rangeSixMaxes
                var sum = maxes.reduce(0, +)
                var average = sum / Float(maxes.count)
                    
        /*
    
    our realNotesFirst array has been incremented by 1024 elements. for each 1024 elements. the elements from 0 - 512 were used to find our maxes. make note that it was not one max taken per 512 elements, but six. each taken as the maximum value of a range. six maxes per 512 elements. rangesOne through rangesSix are then independently reduced to rangeMax arrays. rangeOneMaxes to rangeSixMaxes. where the maximum value in the range was kept. it looks like rangeOne xxxxxxxxxx, xcxcxcxcxc ~ rangeOneMaxes xx or xc. where x or c is a max value used to create our average.
                     
~ ~ ~ the contains method may not be good for step one in a duplicate maximum situation.
~ ~ ~ i changed movieFiltered.
                     
      var movieFiltered : [Float] = []
      var frequency = 0
      var begin = 0
      var end = 19999
      while ( frequency < movieTrim.count / 44100 ) {
      var twentyThousand = movieTrim[begin...end]
      var zeroes = Array(repeating: Float(0), count: 24100)
      twentyThousand += zeroes
      movieFiltered += twentyThousand
      frequency += 1
      begin += 44100
      end += 44100
      }
                     
        1.     each range contains float values. keep the values that are = to their corresponding maximum and make all others zero. example. rangeOne has ten values 0...9 for each 512 ( 1024 ) elements from realNotesFirst. like xxxxxxxxxx, xcxcxcxcxc, xzxzxzxzxz, znznznznzn,, the maximums could be x, c, z, n. here, the first elements from rangeOne xxxxxxxxxx would be compared to the maximum x. a result of 000x000000 is possible or 000000x000 and so on. then xcxcxcxcxc is compared with c. with a possible result of 0c00000000. now we have something like 000x000000, 0c00000000 or 000000x000, 0c00000000, * this should be completed for all 6 independent arrays rangeOne - rangeSix *. this preserves values in the time domain. we can call the arrays highNotesOne - highNotesSix. * note if there are duplicates in any particular range. like 0x0x000000. keep only the first instance of a maximum. like 0x0x000000 to 0x00000000.
                     
        2.     for each highNotes array one - six. keep only the preserved maximums found above that are >= average ( completed ). all other elements should be zero. we are preserving time from above and should not take all elements above the average without completing step 1.
                     
        3.     highNotesOne - highNotesSix should be appended to each other. elements 0 - 512 of our source are now represented. var a = Array(repeating: Float(0), count: 247589) is an array containing all of the padding 0's needed to get backToTime.
                     
        4.

    */
 
        /* ground control. this is spacer. the item below is good for printing each element with it's index.
                
                for (index, element) in .enumerated() {
                print("Item \(index): \(element)") }
      
        */
        
                player.play()
                    
                }
                }
                }
                }
                    
                /*testPlayer = AVPlayer(url: localUrl)
                testPlayer.play()*/
    
    /*@IBAction func helpButtonPressed(_ sender: Any) {
    }*/
    
    @IBAction func playButtonWasPressed(_ sender: Any) {
        if (recorder?.isRecording)! {
            recorder?.stop()
        }
        else {
            recorder?.record(forDuration: 10)
            recorder?.record()
            
            let playImage1:UIImage = UIImage(named: "playPressed")!
            let playImage2:UIImage = UIImage(named: "playReturn")!
            
            playButton.setTitle("playButton", for: [])
            playButton.imageView!.animationImages = [playImage1, playImage2]
            playButton.imageView!.animationDuration = 0.17
            playButton.imageView!.animationRepeatCount = 1
            playButton.imageView!.startAnimating()
            
        }
    }
    
    @IBAction func getButtonWasPressed(_ sender: UIButton) {
        if player.rate != 1.0 {
            // Not playing forward, so play.
            if currentTime == duration {
                // At end, so got back to begining.
                currentTime = 0.0
            }
            
            let getImage1:UIImage = UIImage(named: "getPressed")!
            let getImage2:UIImage = UIImage(named: "getReturn")!
            
            getButton.setTitle("getButton", for: [])
            getButton.imageView!.animationImages = [getImage1, getImage2]
            getButton.imageView!.animationDuration = 0.17
            getButton.imageView!.animationRepeatCount = 1
            getButton.imageView!.startAnimating()
            
        }
        audioRecorderDidFinishRecording(recorder!, successfully: true)
        getHelp.isHidden = true
    }
    
    /*@IBAction func resetButtonWasPressed(_ sender: UIButton) {
    }*/
    
    // MARK: - Asset Loading
    
    func asynchronouslyLoadURLAsset(_ newAsset: AVURLAsset) {
        /*
         Using AVAsset now runs the risk of blocking the current thread (the
         main UI thread) whilst I/O happens to populate the properties. It's
         prudent to defer our work until the properties we need have been loaded.
         */
        newAsset.loadValuesAsynchronously(forKeys: PlayerViewController.assetKeysRequiredToPlay) {
            /*
             The asset invokes its completion handler on an arbitrary queue.
             To avoid multiple threads using our internal state at the same time
             we'll elect to use the main thread at all times, let's dispatch
             our handler to the main queue.
             */
            DispatchQueue.main.async {
                /*
                 `self.asset` has already changed! No point continuing because
                 another `newAsset` will come along in a moment.
                 */
                guard newAsset == self.asset else { return }
                
                /*
                 Test whether the values of each of the keys we need have been
                 successfully loaded.
                 */
                for key in PlayerViewController.assetKeysRequiredToPlay {
                    var error: NSError?
                    
                    if newAsset.statusOfValue(forKey: key, error: &error) == .failed {
                        let stringFormat = NSLocalizedString("error.asset_key_%@_failed.description", comment: "Can't use this AVAsset because one of it's keys failed to load")
                        
                        let message = String.localizedStringWithFormat(stringFormat, key)
                        
                        self.handleErrorWithMessage(message, error: error)
                        
                        return
                    }
                }
                
                // We can't play this asset.
                if !newAsset.isPlayable || newAsset.hasProtectedContent {
                    let message = NSLocalizedString("error.asset_not_playable.description", comment: "Can't use this AVAsset because it isn't playable or has protected content")
                    
                    self.handleErrorWithMessage(message)
                    
                    return
                }
                
                /*
                 We can play this asset. Create a new `AVPlayerItem` and make
                 it our player's current item.
                 */
                self.playerItem = AVPlayerItem(asset: newAsset)
                
            }
        }
    }
    
    // MARK: - IBActions
    
    @IBAction func timeSliderDidChange(_ sender: UISlider) {
        currentTime = Double(sender.value)
    }
    
    // MARK: - KVO Observation
    
    // Update our UI when player or `player.currentItem` changes.
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey: Any]?, context: UnsafeMutableRawPointer?) {
        // Make sure the this KVO callback was intended for this view controller.
        guard context == &playerViewControllerKVOContext else {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
            return
        }
        
        if keyPath == #keyPath(PlayerViewController.player.currentItem.duration) {
            // Update timeSlider and enable/disable controls when duration > 0.0
            
            /*
             Handle `NSNull` value for `NSKeyValueChangeNewKey`, i.e. when
             `player.currentItem` is nil.
             */
            let newDuration: CMTime
            if let newDurationAsValue = change?[NSKeyValueChangeKey.newKey] as? NSValue {
                newDuration = newDurationAsValue.timeValue
            }
            else {
                newDuration = kCMTimeZero
            }
            
            let hasValidDuration = newDuration.isNumeric && newDuration.value != 0
            let newDurationSeconds = hasValidDuration ? CMTimeGetSeconds(newDuration) : 0.0
            let currentTime = hasValidDuration ? Float(CMTimeGetSeconds(player.currentTime())) : 0.0
            
            timeSlider.maximumValue = Float(newDurationSeconds)
            
            timeSlider.value = currentTime
            
            playButton.isEnabled = hasValidDuration
            
            timeSlider.isEnabled = hasValidDuration
            
            startTimeLabel.isEnabled = hasValidDuration
            startTimeLabel.text = createTimeString(time: currentTime)
            
            durationLabel.isEnabled = hasValidDuration
            durationLabel.text = createTimeString(time: Float(newDurationSeconds))
        }
            /*
             else if keyPath == #keyPath(PlayerViewController.player.rate) {
             // Update `playPauseButton` image.
             
             let newRate = (change?[NSKeyValueChangeKey.newKey] as! NSNumber).doubleValue
             
             let buttonImageName = newRate == 1.0 ? "beginRecording" : "seek"
             
             let buttonImage = UIImage(named: buttonImageName)
             
             playPauseButton.setImage(buttonImage, for: UIControlState())
             */
        else if keyPath == #keyPath(PlayerViewController.player.currentItem.status) {
            // Display an error if status becomes `.Failed`.
            
            /*
             Handle `NSNull` value for `NSKeyValueChangeNewKey`, i.e. when `player.currentItem` is nil.
             */
            let newStatus: AVPlayerItemStatus
            
            if let newStatusAsNumber = change?[NSKeyValueChangeKey.newKey] as? NSNumber {
                newStatus = AVPlayerItemStatus(rawValue: newStatusAsNumber.intValue)!
            }
            else {
                newStatus = .unknown
            }
            
            if newStatus == .failed {
                handleErrorWithMessage(player.currentItem?.error?.localizedDescription, error:player.currentItem?.error)
            }
        }
    }
    
    // Trigger KVO for anyone observing our properties affected by player and player.currentItem
    override class func keyPathsForValuesAffectingValue(forKey key: String) -> Set<String> {
        let affectedKeyPathsMappingByKey: [String: Set<String>] = [
            "duration":     [#keyPath(PlayerViewController.player.currentItem.duration)],
            "rate":         [#keyPath(PlayerViewController.player.rate)]
        ]
        
        return affectedKeyPathsMappingByKey[key] ?? super.keyPathsForValuesAffectingValue(forKey: key)
    }
    
    // MARK: - Error Handling
    
    func handleErrorWithMessage(_ message: String?, error: Error? = nil) {
        NSLog("Error occured with message: \(String(describing: message)), error: \(String(describing: error)).")
        
        let alertTitle = NSLocalizedString("alert.error.title", comment: "Alert title for errors")
        let defaultAlertMessage = NSLocalizedString("error.default.description", comment: "Default error message when no NSError provided")
        
        let alert = UIAlertController(title: alertTitle, message: message == nil ? defaultAlertMessage : message, preferredStyle: UIAlertControllerStyle.alert)
        
        let alertActionTitle = NSLocalizedString("alert.error.actions.OK", comment: "OK on error alert")
        
        let alertAction = UIAlertAction(title: alertActionTitle, style: .default, handler: nil)
        
        alert.addAction(alertAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    // MARK: Convenience
    
    func createTimeString(time: Float) -> String {
        let components = NSDateComponents()
        components.second = Int(max(0.0, time))
        
        return timeRemainingFormatter.string(from: components as DateComponents)!
    }
}


// MARK: - Float buffers

extension PlayerViewController {
    
    // this method was only used to demonstrate float buffer functionality, safe to remove.
    func printAudioSamples() {
        
        // open provided test audio files ("test-1.m4a" and "test-2.m4a")
        guard let file1 = openAudioFile(name: "test-1") else { return }
        guard let file2 = openAudioFile(name: "test-2") else { return }
        
        // load files into two independent [Float] buffers
        guard let buffer1 = readIntoFloatBuffer(file: file1) else { return }
        guard let buffer2 = readIntoFloatBuffer(file: file2) else { return }
        
        // output buffers to the console side-by-side including offset in seconds
        let start  = 16.0 // output fragment offset from the beginning, seconds
        let length = 15.0 // output fragment duration, seconds
        let sampleRate = file1.fileFormat.sampleRate
        for frame in Int(start * sampleRate)...Int((start + length) * sampleRate) {
            print(String(format: "%.5f: %.12 13f %.12 13f", Double(frame) / sampleRate, buffer1[frame], buffer2[frame]))
        }
    }
    
    func openAudioFile(url: URL) -> AVAudioFile? {
        do {
            return try AVAudioFile(forReading: url)
        } catch {
            print("failed to open audio file: \(error.localizedDescription)")
            return nil
        }
    }
    
    func openAudioFile(name: String) -> AVAudioFile? {
        guard let url = Bundle.main.url(forResource: name, withExtension: "m4a") else {
            print("failed to find audio file '\(name)'")
            return nil
        }
        do {
            return try AVAudioFile(forReading: url)
        } catch {
            print("failed to open audio file '\(name)': \(error.localizedDescription)")
            return nil
        }
    }
    
    func readIntoFloatBuffer(file: AVAudioFile) -> [Float]? {
        print("reading audio file...")
        let format = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: file.fileFormat.sampleRate,
                                   channels: file.fileFormat.channelCount, interleaved: false)
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(file.length))
        do {
            try file.read(into: buffer)
        } catch {
            print("failed to read audio file: \(error.localizedDescription)")
            return nil
        }
        return Array(UnsafeBufferPointer(start: buffer.floatChannelData?[0], count: Int(buffer.frameLength)))
    }
    
    func writeFloatBuffer(_ buffer: [Float], intoFile filename: String) {
        print("writing text file...")
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent(filename)
        
        if let out = OutputStream(url: url, append: false) {
            out.open()
            var lines = 0
            for frame in buffer {
                let data = "\(frame)\n".data(using: .utf8)!
                let _ = data.withUnsafeBytes { out.write($0, maxLength: data.count) }
                lines += 1
                if lines % 1000000 == 0 {
                    print("\(lines / 1000000)M lines")
                }
                
                if lines == 30000 { break }
            }
            out.close()
        }
        print("successfully written '\(url.absoluteString)': \(buffer.count) lines")
    }
    
    func download(url: URL, to localUrl: URL, completion: @escaping () -> Void) {
        print("downloading \(url.absoluteString)")
        let task = URLSession.shared.downloadTask(with: URLRequest(url: url)) { (tempLocalUrl, response, error) in
            if let tempLocalUrl = tempLocalUrl, error == nil {
                do {
                    let _ = try FileManager.default.replaceItemAt(localUrl, withItemAt: tempLocalUrl)
                    completion()
                } catch {
                    print("error writing file '\(localUrl)': \(error)")
                }
            } else {
                print("download failed");
            }
        }
        task.resume()
    }
    
    func documentUrl(for name: String) -> URL {
        return FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent(name)
    }
}
